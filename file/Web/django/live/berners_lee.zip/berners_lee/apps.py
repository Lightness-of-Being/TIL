from django.apps import AppConfig


class BernersLeeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'berners_lee'
